# DOG-breed-detection
This is a project to detect dog breeds using TensorFlow, this is in its nature a multi-class classification problem! All the details that you expect in the "README" section is in the notebook : ) The code for using custom data will be uploaded later!
